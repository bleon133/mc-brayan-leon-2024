#Brayan Steven León Martinez - Parcial 1 - Matemáticas Computacional

A = set([1, 4, 6, 9, 12, 20])

print("A=")
print(A)

B = set([2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14])

print("B=")
print(B)

C = set([6, 10, 14, 18])

print("C=")
print(C)

print("(B ⨁ C) ⋂ (A ⋃ C):")
print(((B^C)&(A|C)))

print("((A − B) ∩ C)⨁(B ⋃ C)")
print((((A - B) & C) ^ (B | C)))

print("((A − C) ⋃ (B ∩ A)) − (A ⋃ B ⋃ C))")
print((((A - C) | (B & A)) - (A | B | C)))